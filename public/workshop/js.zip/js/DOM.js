// Module 5: DOM Manipulation and Events

// 1. Introduction to the DOM

// Selecting Elements
let heading = document.getElementById("main-heading");
console.log(heading.textContent);

// Modifying Elements
heading.textContent = "New Heading";
heading.style.color = "blue";

// Creating and Appending Elements
let paragraph = document.createElement("p");
paragraph.textContent = "This is a new paragraph.";
document.body.appendChild(paragraph);

// 2. DOM Manipulation

// Removing Elements
let list = document.getElementById("list");
let firstItem = list.firstElementChild;
list.removeChild(firstItem);

// 3. Events

// Adding Event Listeners
let button = document.getElementById("my-button");
button.addEventListener("click", function () {
  alert("Button clicked!");
});

// Event Object
document.addEventListener("keydown", function (event) {
  console.log("Key pressed: " + event.key);
});

// 4. Asynchronous JavaScript

// Callbacks
setTimeout(function () {
  console.log("Timeout expired.");
}, 2000);

// Promises
let promise = new Promise(function (resolve, reject) {
  setTimeout(function () {
    resolve("Promise resolved.");
  }, 3000);
});

promise.then(function (result) {
  console.log(result);
});

// Async/Await
async function fetchData() {
  let response = await fetch("https://api.example.com/data");
  let data = await response.json();
  console.log(data);
}

fetchData();

// Module 5: DOM Manipulation and Events

document.addEventListener("DOMContentLoaded", function () {
  fetchUsers();
});

async function fetchUsers() {
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/users");
    const data = await response.json();
    displayUsers(data);
  } catch (error) {
    console.error("Error fetching users:", error);
  }
}

function displayUsers(users) {
  const userList = document.getElementById("user-list");

  users.forEach(function (user) {
    const listItem = document.createElement("li");
    listItem.textContent = user.name;
    userList.appendChild(listItem);
  });
}
