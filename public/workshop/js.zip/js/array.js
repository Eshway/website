// Module 4: Arrays and Objects

// 1. Arrays

// Array Declaration
let numbers = [1, 2, 3, 4, 5];
let fruits = ["Apple", "Banana", "Orange"];

// Array Elements
console.log(numbers[0]); // Accessing the first element of the array

// Common Array Operations
fruits.push("Grapes"); // Adding an element to the end of the array
console.log(fruits);

fruits.pop(); // Removing the last element from the array
console.log(fruits);

// 2. Objects

// Object Declaration
let person = {
  name: "John Doe",
  age: 30,
  isStudent: false,
};

// Accessing Object Properties
console.log(person.name); // Dot notation
console.log(person["age"]); // Bracket notation

// Object Methods
let car = {
  brand: "Toyota",
  model: "Corolla",
  start: function () {
    console.log("Engine started.");
  },
};

car.start();

// 3. Array Methods
// let numbers = [1, 2, 3, 4, 5];
// map()
let doubledNumbers = numbers.map((num) => num * 2);
console.log(doubledNumbers);

// filter()
let evenNumbers = numbers.filter((num) => num % 2 === 0);
console.log(evenNumbers);

// reduce()
let sum = numbers.reduce((total, num) => total + num, 0);
console.log(sum);

// forEach()
fruits.forEach((fruit) => {
  console.log("I love " + fruit);
});

// 4. Working with JSON

// JSON Syntax
let jsonStr = '{"name": "John", "age": 30}';

let jsonObj = JSON.parse(jsonStr);
console.log(jsonObj);

// Stringifying JSON
let jsonString = JSON.stringify(person);
console.log(jsonString);
