// 1. Conditional Statements

// if Statement
let num = 10;

if (num > 0) {
  console.log("Number is positive");
} else if (num < 0) {
  console.log("Number is negative");
} else {
  console.log("Number is zero");
}

// switch Statement
let day = "Monday";

switch (day) {
  case "Monday":
    console.log("Today is Monday");
    break;
  case "Tuesday":
    console.log("Today is Tuesday");
    break;
  default:
    console.log("Unknown day");
}

// 2. Loops

// for Loop
for (let i = 0; i < 5; i++) {
  console.log("Iteration " + (i + 1));
}

// while Loop
let count = 0;
while (count < 3) {
  console.log("Count: " + count);
  count++;
}

// do...while Loop
let x = 1;
do {
  console.log("Value of x: " + x);
  x++;
} while (x <= 3);

// 3. Functions

// Function Declaration
function greet(name) {
  return "Hello, " + name + "!";
}

console.log(greet("Alice"));

// Function Expression
let multiply = function (a, b) {
  return a * b;
};

console.log("Multiplication: " + multiply(2, 3));


// Arrow Functions
let add = (num1, num2) => num1 + num2;

console.log("Addition: " + add(5, 7));

// 4. Scope and Closures

// Lexical Scope
function outerFunction() {
  let outerVar = "I'm outer";

  function innerFunction() {
    let innerVar = "I'm inner";
    console.log(innerVar); // Accessing innerVar
    console.log(outerVar); // Accessing outerVar
  }

  innerFunction();
  // console.log(innerVar); // Error: innerVar is not defined
}

outerFunction();

// Closure
function createCounter() {
  let count = 0;
  return function () {
    return ++count;
  };
}

let counter = createCounter();
console.log(counter()); // 1
console.log(counter()); // 2
console.log(counter()); // 3
