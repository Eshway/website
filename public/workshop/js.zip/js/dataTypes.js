// 1. Primitive Data Types

// Numbers
let age = 25;
let height = 175.5;

// Strings
let name = "John Doe";
let message = "Hello, world!";

// Booleans
let isStudent = true;
let isLoggedIn = false;

// Null and Undefined
let x = null;
let y; // undefined

// Symbols (ES6)
const symbol1 = Symbol("description");
const symbol2 = Symbol("description");

console.log(typeof age); // "number"
console.log(typeof name); // "string"
console.log(typeof isStudent); // "boolean"
console.log(typeof x); // "object" (typeof null returns "object")
console.log(typeof y); // "undefined"
console.log(typeof symbol1); // "symbol"
console.log(symbol1 === symbol2); // false (Symbols are unique)

// 2. Variables

// Declaring and initializing variables
let score = 100;
const PI = 3.14;

// Variable assignment
score = 200;

// 3. Variable Scope

// Global scope
let globalVar = "I'm global";

function testScope() {
  // Function scope
  let localVar = "I'm local";
  console.log(globalVar); // Accessible
}

testScope();
// console.log(localVar); // Error: localVar is not defined

// 4. Constants

const MAX_VALUE = 100;
// MAX_VALUE = 200; // Error: Assignment to constant variable

console.log(MAX_VALUE);
