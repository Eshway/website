const express = require("express");
const bodyParser = require("body-parser");

const app = express();
const port = 3000;

// Sample data
let items = [
  { id: 1, name: "Item 1" },
  { id: 2, name: "Item 2" },
  { id: 3, name: "Item 3" },
];

// Middleware
app.use(bodyParser.json());

// Routes
app.get("/items", (req, res) => {
  res.json(items);
});

app.post("/items", (req, res) => {
  const newItem = req.body;
  items.push(newItem);
  res.status(201).json(newItem);
});

app.get("/items/:id", (req, res) => {
  const itemId = parseInt(req.params.id);
  const item = items.find((item) => item.id === itemId);
  if (item) {
    res.json(item);
  } else {
    res.status(404).send("Item not found");
  }
});

app.put("/items/:id", (req, res) => {
  const itemId = parseInt(req.params.id);
  const updatedItem = req.body;
  const index = items.findIndex((item) => item.id === itemId);
  if (index !== -1) {
    items[index] = { ...items[index], ...updatedItem };
    res.json(items[index]);
  } else {
    res.status(404).send("Item not found");
  }
});

app.delete("/items/:id", (req, res) => {
  const itemId = parseInt(req.params.id);
  const initialLength = items.length;
  items = items.filter((item) => item.id !== itemId);
  if (items.length < initialLength) {
    res.status(204).send();
  } else {
    res.status(404).send("Item not found");
  }
});

// Error handling middleware
app.use((req, res, next) => {
  res.status(404).send("Not Found");
});

// Start server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
