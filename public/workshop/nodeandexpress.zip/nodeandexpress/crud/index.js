const express = require("express");
const app = express();
const users = [];

app.use(express.json());

// GET /api/users - Get all users
app.get("/api/users", (req, res) => {
  res.json(users);
});

//GET /api/users via :id
app.get("/api/users/:id", (req, res) => {
  const id = req.params.id;
  const user = users.find((user) => user.student_id === id);
  if (user) {
    res.json(user);
  } else {
    res.status(404).send("User not found");
  }
});

// POST /api/users - Create a new user
app.post("/api/users", (req, res) => {
  const { student_id, username, designation } = req.body;
  // console.log(student_id, username, designation);
  users.push({
    student_id: student_id,
    username: username,
    designation: designation,
  });
  res.status(201).json(users);
});

// // PUT /api/users/:id - Update an existing user
// app.put("/api/users/:id", (req, res) => {
//   const id = req.params.id;
//   // Update user with id
//   res.status(204).end();
// });

// // DELETE /api/users/:id - Delete an existing user
// app.delete("/api/users/:id", (req, res) => {
//   const id = req.params.id;
//   // Delete user with id
//   res.status(204).end();
// });

app.listen(3000, () => {
  console.log("Server is running on port 3000");
});
