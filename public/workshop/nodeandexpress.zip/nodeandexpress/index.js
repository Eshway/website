const express = require("express");
const app = express();

app.get("/", (req, res) => {
  res.send("Hello, Express!");
});
app.get("/eshu", (req, res) => {
  res.send("HELLO eshu");
});
app.get("/about", (req, res) => {
  res.send("About my application");
});
app.get("/contact", (req, res) => {
  res.send("Contact");
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
