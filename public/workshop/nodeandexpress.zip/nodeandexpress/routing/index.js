const express = require("express");
const app = express();

// Define a route handler for the GET method
app.get("/", (req, res) => {
  res.send("Hello, GET request!");
});

// Define a route handler for the POST method
app.post("/users", (req, res) => {
  res.send("Hello, POST request!");
});

// Define a route handler for the PUT method
app.put("/users/:id", (req, res) => {
  res.send(`Hello, PUT request for user ${req.params.id}!`);
});

// Define a route handler for the DELETE method
app.delete("/users/:id", (req, res) => {
  res.send(`Hello, DELETE request for user ${req.params.id}!`);
});

app.listen(3000, () => {
  console.log("Server is running on port 3000");
});
