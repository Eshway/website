const express = require("express");
const app = express();
const PORT = 3000;

app.get("/", (req, res) => {
    res.send("THIS IS MY EXPRESS SERVER");
});
app.get("/eshu", (req, res) => {
    res.send("This is /eshu ROUTE");
});
app.get("/new", (req, res) => {
    res.send("This is /new ROUTE");
});

app.get("/another", (req, res) => {
    res.send("This is /another ROUTE");
});

app.listen(PORT, () => {console.log("SERVER RUNNNING");
});

