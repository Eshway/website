import React from 'react'

const AboutMe = () => {
  return (
    <div>THIS IS MY ABOUT PAGE</div>
  )
}

export default AboutMe