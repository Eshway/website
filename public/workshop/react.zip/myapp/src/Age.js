import React from 'react'

const Age = (props) => {
  return (
    <div>My Age is {props.myage}</div>
  )
}

export default Age