import AboutMe from "./AboutMe";
import Home from "./Home";
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
function App() {
  return (
    <Router>
      <nav>
        <ul>
          <Link to="/"><li>Home Page</li></Link>
          <Link to="/eshu"><li>About Page</li></Link>
        </ul>
      </nav>
      <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/eshu" element={<AboutMe />} />
      </Routes>
    </Router>
  );
}

export default App;
