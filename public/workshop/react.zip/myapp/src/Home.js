import React from 'react'

const Home = () => {
  return (
    <>THIS IS MY HOME PAGE</>
  )
}

export default Home