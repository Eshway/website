import React from 'react'

const Name = (props) => {
  return (
    <div>My name is {props.myname}</div>
  )
}

export default Name