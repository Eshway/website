// src/App.js
import React from 'react';
import { ThemeProvider } from './ThemeContext';
import Navbar from './components/Navbar';
import ThemeToggler from './components/ThemeToggler';

function App() {
  return (
    <ThemeProvider>
      <div className="App">
        <Navbar />
        <ThemeToggler />
      </div>
    </ThemeProvider>
  );
}

export default App;
