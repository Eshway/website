// src/components/Navbar.js
import React, { useContext } from 'react';
import { ThemeContext } from '../ThemeContext';


function Navbar() {
  const { theme } = useContext(ThemeContext);

  return (
    <nav style={{ background: theme === 'light' ? '#eee' : '#333', color: theme === 'light' ? '#000' : '#fff' }}>
      <h1>{theme === 'light' ? 'Light Theme' : 'Dark Theme'}</h1>
    </nav>
  );
}

export default Navbar;
